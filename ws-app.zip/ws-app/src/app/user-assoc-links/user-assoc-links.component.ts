import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-assoc-links',
  templateUrl: './user-assoc-links.component.html',
  styleUrls: ['./user-assoc-links.component.scss']
})
export class UserAssocLinksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
