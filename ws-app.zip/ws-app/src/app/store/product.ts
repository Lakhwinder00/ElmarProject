export interface Product {
  id: string;
  firstName: string;
  lastName: string;
  email: number;
  customerMemberId: string;
}
